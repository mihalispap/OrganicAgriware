
GEOLOCATION GENERATOR
=====================
Allows you to generate a cluster of random map locations for Views displayed
as maps via the module IP Geolocation Views and Maps.

On the Geolocation Generator configuration page you specify the center of the
cluster and the latitude and longitude ranges as well as the number of
locations (markers) to generate.

The random markers will appear in the selected default marker colour and are
added to all map displays of the selected Views.


AUTHOR
======
Rik de Boer of flink dot com dot au, Melbourne, Australia.
